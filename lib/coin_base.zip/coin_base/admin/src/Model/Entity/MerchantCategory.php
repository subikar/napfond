<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * MerchantCategory Entity.
 */
class MerchantCategory extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * @var array
     */
    protected $_accessible = [
        'merchant_id' => true,
        'category_id' => true,
        'merchant' => true,
        'category' => true,
    ];
}
