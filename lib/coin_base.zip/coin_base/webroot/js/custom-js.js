jQuery(document).ready(function(){
    
    jQuery('.loading').hide();
    
    jQuery('.lang-select').change(function(){
        
    }).trigger('change');
    
    jQuery('.white-arrow-select').html(jQuery('.lang-select option:selected').html());
});