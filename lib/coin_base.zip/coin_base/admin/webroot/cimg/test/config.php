<?php
// Use error reporting
error_reporting(-1);
ini_set('display_errors', 1);


// The link to img.php
$imgphp = "../img.php?src=";
