<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Utility\Hash;
use Cake\Core\Configure;

/**
 * Merchants Controller
 *
 * @property \App\Model\Table\MerchantsTable $Merchants
 * @property \App\Model\Table\FilesTable $Files
 */
class MerchantsController extends AppController
{

    /**
     * Index method
     *
     * @return void
     */
    public function index()
    {
        $this->paginate = [
            'contain'       => ['AffiliateNetworks'],
            'sort'          => 'id',
            'direction'     => 'desc',
        ];
        $this->set('merchants', $this->paginate($this->Merchants));
        $this->set('_serialize', ['merchants']);
    }

    /**
     * View method
     *
     * @param string|null $id Merchant id.
     * @return void
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function view($id = null)
    {
        $merchant = $this->Merchants->get($id, [
            'contain' => ['AffiliateNetworks','Categories','Tags']
        ]);
        $this->set('merchant', $merchant);
        $this->set('_serialize', ['merchant']);
    }

    /**
     * Add method
     *
     * @return void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->Categories   = TableRegistry::get('Categories');
        $this->Tags         = TableRegistry::get('Tags');
        $this->Files        = TableRegistry::get('Files');
        $selCategories      = [];
        
        $merchant = $this->Merchants->newEntity();
        
        if ($this->request->is('post')) {
            
            if(!empty($this->request->data['tag'])){
                $tags   = explode(",",$this->request->data['tag']);
                $dbTags = $this->Tags->find('list')
                            ->where(function ($exp, $q) use ($tags) {
                                return $exp->in('name', $tags);
                            })->toArray();
            }
            
            $merchant       = $this->Merchants->patchEntity($merchant, $this->request->data);
            //pr($merchant);
            //echo $merchant->name;
            //die('till here all seems ok to us');
            if(!isset($this->request->data['logo']['error'])?$this->request->data['logo']['error']:FALSE){
                $logo               = $this->Files->saveFile($this->current_user['id'],$this->request->data['logo']);
                $merchant->logo     = $logo->id;
            }
            
            /**
             * 
             * @todo  Validation Error needs to be checked here and Post the
             * Validation error message Accordingly over here.
             */
            
            $status = $this->Merchants->save($merchant);
            
            if ($status) {
                
                if(!isset($this->request->data['logo']['error'])?$this->request->data['logo']['error']:TRUE){
                    /*$fileHash           = md5($merchant->id . '_' .$this->request->data['logo']['name']);
                    $fileExtention      = pathinfo($this->request->data['logo']['name'], PATHINFO_EXTENSION);
                    $fileName           = $fileHash . "." . $fileExtention;
                    $fileDestination    = Configure::read('Simgupload') .  $fileName;
                    move_uploaded_file($this->request->data['logo']['tmp_name'],$fileDestination);*/
                    $file = $this->Files->saveFile($this->current_user['id'], $this->request->data['logo']);
                    if($file){
                        $merchant->logo = $file->id;
                        $this->Merchants->save($merchant);
                    }
                }
                $this->Flash->success('The merchant has been saved.');
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error('The merchant could not be saved. Please, try again.');
            }
        }
        Skip:
        $affiliateNetworks  = $this->Merchants->AffiliateNetworks->find('list',[
            'keyField'      => 'id',
            'valueField'    => 'name',
        ]);
        $tags               = $this->Tags->find('list',[
            'keyField'      => 'id',
            'valueField'    => 'name',
        ]);               
        $categories         = $this->Categories->find('list',[
            'keyField'      => 'id',
            'valueField'    => 'name',
        ]);               
        
        $this->set('selCategories'  ,$selCategories);
        $this->set('isEdit',FALSE);
        $this->set(compact('merchant', 'affiliateNetworks','tags','categories'));
        $this->set('_serialize', ['merchant','affiliateNetworks','tags','categories']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Merchant id.
     * @return void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        
        $this->Categories   = TableRegistry::get('Categories');
        $this->Tags         = TableRegistry::get('Tags');
        $selCategories      = [];
        
        $merchant = $this->Merchants->get($id, [
            'contain' => ['AffiliateNetworks','Categories','Tags']
        ]);
        
        if ($this->request->is(['patch', 'post', 'put'])) {
            if(isset($this->request->data['tag'])){
                $tags           = explode(",",$this->request->data['tag']);
                $databaseTags   = $this->Tags->find('all',[
                    'keyField'      => 'name',
                    'valueField'    => 'tag',
                    'Condition'     => ['Tags.name IN '=>$tags]
                ])->reduce(function($output,$value){
                    $Object         = $value->toArray();
                    unset($Object['created']);
                    unset($Object['modified']);
                    unset($Object['parent']);
                    $output[$value->name]   = $Object;
                    return $output;
                },[]);
                foreach($tags as $tag){
                    if(in_array($tag, array_keys($databaseTags))){
                        $finalTags[]['Tag'] = $databaseTags[$tag];
                    }else{
                        $finalTags[]['Tag'] = [
                            'name'  => $tag
                        ];
                    }
                }
                unset($this->request->data['tag']);
                $this->request->data['tags']    = $finalTags; 
            }
            
            
            $merchant = $this->Merchants->patchEntity($merchant, $this->request->data);
            
            if ($this->Merchants->save($merchant)) {
                $this->Flash->success('The merchant has been saved.');
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error('The merchant could not be saved. Please, try again.');
            }
        }
        
        $affiliateNetworks = $this->Merchants->AffiliateNetworks->find('list', [
            'keyField'      => 'id',
            'valueField'    => 'name',
        ]);
        $tags               = $this->Tags->find('list',[
            'keyField'      => 'id',
            'valueField'    => 'name',
        ]);               
        $categories         = $this->Categories->find('list',[
            'keyField'      => 'id',
            'valueField'    => 'name',
        ]);
        
        if(count($merchant->categories)>0){
            foreach($merchant->categories  as $category){
                $selCategories[] = $category->id;
            }
        }
        $this->set('selCategories'  ,$selCategories);
        $this->set(compact('merchant', 'affiliateNetworks','tags','categories'));
        $this->set('_serialize', ['merchant','tags','categories','affiliateNetworks']);
        $this->set('isEdit',TRUE);
        $this->view = 'add';
    }

    /**
     * Delete method
     *
     * @param string|null $id Merchant id.
     * @return void Redirects to index.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $merchant = $this->Merchants->get($id);
        if ($this->Merchants->delete($merchant)) {
            $this->Flash->success('The merchant has been deleted.');
        } else {
            $this->Flash->error('The merchant could not be deleted. Please, try again.');
        }
        return $this->redirect(['action' => 'index']);
    }
}
